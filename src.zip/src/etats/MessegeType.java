package etats;

public enum MessegeType {
    SHOT_REQUEST,
    SHOT_RESPONSE,
    PLACE_SHIP,
    SERVER_SHOT,
    NEW_GAME,
    SET_USERNAME,
    GAME_MODE,
    MATCHMAKING,
    OPPONENT_SHOT,
    GAME_START,
    OPPONENT_LEFT,
    REMATCH_RESPONSE,
    INFO,
    ERROR
}